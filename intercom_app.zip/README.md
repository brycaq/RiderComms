# Intercom

Cross-platform (Flutter) intercom app. Discovers nearby users via Bluetooth /
Wi-Fi (MultipeerConnectivity on iOS, Nearby Connections on Android), lets one
device host a session for others to join, and supports push-to-talk audio
between connected peers.

## Why the repo is structured this way

Flutter projects contain a large amount of generated boilerplate (Gradle
wrapper, Xcode project files, plugin registrant code) that shouldn't be
hand-written or hand-edited. This repo keeps only the code that's actually
custom in `custom/`, and `scripts/setup.sh` runs the standard `flutter
create` scaffolding, then overlays the custom Dart + native code and merges
the required permissions. This is the same pattern most real Flutter
projects with custom native modules use.

```
intercom_app/
  custom/
    lib/                     # Dart app (cross-platform)
      discovery_bridge.dart  # single interface over native discovery modules
      session_state.dart     # host/join/peer state, shared on both platforms
      audio_service.dart     # push-to-talk record/playback
      screens/
    android_native/          # Kotlin: Nearby Connections API wrapper
    ios_native/               # Swift: MultipeerConnectivity wrapper
  scripts/setup.sh           # flutter create + merge custom code
  .github/workflows/build.yml # CI: builds Android APK + iOS (no codesign)
```

## Building locally

Requires the [Flutter SDK](https://flutter.dev/docs/get-started/install)
(this repo does not vendor it).

```bash
git clone <this-repo>
cd intercom_app
./scripts/setup.sh      # generates app/ and installs dependencies
cd app
flutter run              # needs 2+ physical devices - simulators can't do BLE/Wi-Fi discovery
```

## CI

`.github/workflows/build.yml` runs `setup.sh` then builds a debug Android
APK and an unsigned iOS build on every push to `main`. This is the
"automatically compiles" part - push to GitHub and Actions builds it for
you. (I couldn't run this build myself while writing it: this sandbox has
no Flutter SDK and no network access to fetch one, so treat the first CI
run as the real first compile and check the Actions tab for errors.)

## Architecture notes / known simplifications

- **Star topology**: joiners connect to the host; there's no peer-to-peer
  mesh. Fine for a single-host intercom; if you want any peer to relay to
  any other, the host needs to forward `dataReceived` bytes to its other
  connected peers.
- **Push-to-talk, not continuous streaming**: audio is recorded to a short
  AAC clip, sent as bytes, and played back on receipt. This is far more
  reliable than an open mic over BLE/Wi-Fi Direct and is what most apps in
  this space actually ship. Continuous low-latency streaming would mean
  replacing `record`/`audioplayers` with a native audio engine
  (AVAudioEngine / Oboe) feeding raw PCM frames into the same data channel
  in small chunks with a jitter buffer - a meaningfully bigger project.
- **Auto-accept connections**: both native modules currently auto-accept
  incoming connection requests. For anything beyond a prototype you'll want
  to surface an accept/reject prompt to the host.
- **Peer identity**: iOS uses `MCPeerID.displayName` as the peer ID, which
  isn't guaranteed unique. Fine for a demo; swap in a UUID exchanged via
  discovery info before shipping.
- **Android manifest / iOS permission strings**: `setup.sh` merges these in
  automatically. If you ever regenerate `app/` by hand, re-check
  `custom/android_native/AndroidManifest_permissions.xml` and
  `custom/ios_native/Info_permissions.plist` got applied.

## What to build next

- Host-side relay so joiners can hear each other, not just the host
- Accept/reject UI for incoming connection requests
- Continuous streaming mode (see note above) as an alternative to push-to-talk
- Session persistence / reconnect-on-drop handling
